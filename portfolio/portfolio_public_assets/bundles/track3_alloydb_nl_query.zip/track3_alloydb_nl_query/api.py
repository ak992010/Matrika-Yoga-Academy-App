from __future__ import annotations

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.exc import SQLAlchemyError

from config import settings
from db import get_engine
from guards import is_safe_select_query, normalize_sql

app = FastAPI(
    title="Track 3 AlloyDB Natural-Language Query API",
    version="1.0.0",
    description="Converts natural-language questions into SQL with AlloyDB AI NL and returns results from a custom dataset.",
)


class NaturalLanguageQueryRequest(BaseModel):
    question: str = Field(..., min_length=8, max_length=500)


class NaturalLanguageQueryResponse(BaseModel):
    question: str
    generated_sql: str
    columns: list[str]
    rows: list[dict[str, object]]
    row_count: int
    nl_config_id: str


def _ensure_database_configured() -> None:
    if not settings.database_url:
        raise HTTPException(
            status_code=500,
            detail="DATABASE_URL is not configured. Set it before calling this endpoint.",
        )


def _generate_sql(question: str) -> str:
    engine = get_engine()
    statement = text(
        "SELECT alloydb_ai_nl.get_sql(:config_id, :question) ->> 'sql' AS generated_sql"
    )
    with engine.connect() as connection:
        generated_sql = connection.execute(
            statement,
            {
                "config_id": settings.nl_config_id,
                "question": question,
            },
        ).scalar_one_or_none()

    cleaned = normalize_sql(generated_sql or "")
    if not cleaned:
        raise HTTPException(status_code=502, detail="AlloyDB AI NL did not return a SQL statement.")
    if not is_safe_select_query(cleaned):
        raise HTTPException(
            status_code=400,
            detail="Generated SQL was rejected by the read-only safety guard.",
        )
    return cleaned


def _execute_sql(sql_query: str) -> tuple[list[str], list[dict[str, object]]]:
    engine = get_engine()
    with engine.connect() as connection:
        result = connection.execute(text(sql_query))
        columns = list(result.keys())
        fetched = result.fetchmany(settings.row_limit + 1)

    has_more = len(fetched) > settings.row_limit
    limited = fetched[: settings.row_limit]
    rows = [dict(zip(columns, row, strict=False)) for row in limited]
    if has_more:
        rows.append({"notice": f"Result truncated to {settings.row_limit} rows."})
    return columns, rows


@app.get("/healthz")
def healthz() -> dict[str, object]:
    return {
        "status": "ok",
        "service": settings.app_name,
        "database_configured": bool(settings.database_url),
        "nl_config_id": settings.nl_config_id,
    }


@app.get("/sample-questions")
def sample_questions() -> dict[str, list[str]]:
    return {
        "questions": [
            "Which premium customers have open billing tickets in Singapore?",
            "Show unresolved high-priority tickets assigned to Mira.",
            "Which organizations in Japan reported the lowest average CSAT?",
            "Count open technical tickets created after 2026-03-01.",
        ]
    }


@app.post("/query", response_model=NaturalLanguageQueryResponse)
def query(payload: NaturalLanguageQueryRequest) -> NaturalLanguageQueryResponse:
    _ensure_database_configured()

    try:
        generated_sql = _generate_sql(payload.question)
        columns, rows = _execute_sql(generated_sql)
    except HTTPException:
        raise
    except SQLAlchemyError as exc:
        raise HTTPException(status_code=500, detail=f"Database error: {exc}") from exc

    return NaturalLanguageQueryResponse(
        question=payload.question,
        generated_sql=generated_sql,
        columns=columns,
        rows=rows,
        row_count=len(rows),
        nl_config_id=settings.nl_config_id,
    )

