from __future__ import annotations

import re

WRITE_KEYWORDS = re.compile(
    r"\b(ALTER|CALL|COPY|CREATE|DELETE|DROP|GRANT|INSERT|MERGE|REVOKE|TRUNCATE|UPDATE)\b",
    re.IGNORECASE,
)


def normalize_sql(sql: str) -> str:
    return re.sub(r"\s+", " ", sql or "").strip().rstrip(";")


def is_safe_select_query(sql: str) -> bool:
    cleaned = normalize_sql(sql)
    if not cleaned:
        return False
    if WRITE_KEYWORDS.search(cleaned):
        return False
    if ";" in cleaned:
        return False
    upper = cleaned.upper()
    return upper.startswith("SELECT ") or upper.startswith("WITH ")

