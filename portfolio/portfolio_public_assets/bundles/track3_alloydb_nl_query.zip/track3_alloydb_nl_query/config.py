from __future__ import annotations

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "track3-alloydb-nl-query"
    database_url: str = Field(default="", validation_alias="DATABASE_URL")
    nl_config_id: str = Field(
        default="support_helpdesk_nl_config",
        validation_alias="TRACK3_NL_CONFIG_ID",
    )
    row_limit: int = Field(default=25, validation_alias="TRACK3_ROW_LIMIT")

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")


settings = Settings()

