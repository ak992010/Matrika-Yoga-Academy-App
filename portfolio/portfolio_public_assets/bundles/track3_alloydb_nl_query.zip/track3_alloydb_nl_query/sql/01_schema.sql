CREATE SCHEMA IF NOT EXISTS helpdesk;

CREATE TABLE IF NOT EXISTS helpdesk.organizations (
  organization_id BIGINT PRIMARY KEY,
  organization_name TEXT NOT NULL,
  plan_tier TEXT NOT NULL,
  region TEXT NOT NULL,
  headquarters_city TEXT NOT NULL,
  primary_contact TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS helpdesk.support_tickets (
  ticket_id BIGINT PRIMARY KEY,
  organization_id BIGINT NOT NULL REFERENCES helpdesk.organizations(organization_id),
  category TEXT NOT NULL,
  priority TEXT NOT NULL,
  status TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL,
  resolved_at TIMESTAMPTZ,
  assigned_to TEXT NOT NULL,
  customer_sentiment TEXT NOT NULL,
  csat_score NUMERIC(3, 1),
  summary TEXT NOT NULL
);

COMMENT ON SCHEMA helpdesk IS 'Support analytics dataset for a SaaS help desk.';
COMMENT ON TABLE helpdesk.organizations IS 'Customer organizations using the SaaS platform.';
COMMENT ON TABLE helpdesk.support_tickets IS 'Support tickets raised by organizations for billing, product, and onboarding issues.';

COMMENT ON COLUMN helpdesk.organizations.plan_tier IS 'Subscription plan of the customer. Common values are starter, growth, premium, and enterprise.';
COMMENT ON COLUMN helpdesk.organizations.region IS 'Regional market label such as APAC North, APAC South, or SEA.';
COMMENT ON COLUMN helpdesk.organizations.headquarters_city IS 'Primary operating city for the organization.';
COMMENT ON COLUMN helpdesk.support_tickets.category IS 'Ticket topic such as billing, technical, onboarding, or feature request.';
COMMENT ON COLUMN helpdesk.support_tickets.priority IS 'Operational urgency of the ticket. Common values are low, medium, high, or urgent.';
COMMENT ON COLUMN helpdesk.support_tickets.status IS 'Current state of the ticket. Common values are open, in_progress, waiting_customer, or resolved.';
COMMENT ON COLUMN helpdesk.support_tickets.customer_sentiment IS 'Qualitative sentiment extracted from the latest customer message.';
COMMENT ON COLUMN helpdesk.support_tickets.csat_score IS 'Customer satisfaction score after resolution on a 1.0 to 5.0 scale.';

