CREATE EXTENSION IF NOT EXISTS alloydb_ai_nl cascade;

SELECT alloydb_ai_nl.g_create_configuration(
  'support_helpdesk_nl_config'
);

SELECT alloydb_ai_nl.g_manage_configuration(
  operation => 'register_schema',
  configuration_id_in => 'support_helpdesk_nl_config',
  schema_names_in => '{helpdesk}'
);

SELECT alloydb_ai_nl.g_manage_configuration(
  'add_general_context',
  'support_helpdesk_nl_config',
  general_context_in => '{
    "Use case: Exploring customer support tickets for a SaaS help desk.",
    "A premium customer is any organization whose plan_tier is premium or enterprise.",
    "Open work includes tickets with status open, in_progress, or waiting_customer."
  }'
);

SELECT alloydb_ai_nl.generate_schema_context(
  'support_helpdesk_nl_config'
);

SELECT alloydb_ai_nl.apply_generated_schema_context(
  'support_helpdesk_nl_config',
  TRUE
);
