INSERT INTO helpdesk.organizations (
  organization_id,
  organization_name,
  plan_tier,
  region,
  headquarters_city,
  primary_contact
) VALUES
  (101, 'Harbor Cloud', 'premium', 'SEA', 'Singapore', 'Alicia Tan'),
  (102, 'Seoul Metrics', 'enterprise', 'APAC North', 'Seoul', 'Ji-hoon Park'),
  (103, 'Kyoto Retail Labs', 'growth', 'APAC North', 'Kyoto', 'Emi Sato'),
  (104, 'Sydney Ops Grid', 'premium', 'APAC South', 'Sydney', 'Liam Cooper'),
  (105, 'Jakarta Ledger', 'starter', 'SEA', 'Jakarta', 'Rizky Putra'),
  (106, 'Bengal Scaleworks', 'enterprise', 'APAC South', 'Bengaluru', 'Naina Rao')
ON CONFLICT (organization_id) DO NOTHING;

INSERT INTO helpdesk.support_tickets (
  ticket_id,
  organization_id,
  category,
  priority,
  status,
  created_at,
  resolved_at,
  assigned_to,
  customer_sentiment,
  csat_score,
  summary
) VALUES
  (5001, 101, 'billing', 'high', 'open', '2026-03-02 09:00:00+00', NULL, 'Mira', 'frustrated', NULL, 'Invoice duplicated after annual renewal.'),
  (5002, 101, 'technical', 'medium', 'resolved', '2026-02-12 08:30:00+00', '2026-02-13 14:10:00+00', 'Rohan', 'neutral', 4.3, 'API webhook retries stalled for one region.'),
  (5003, 102, 'security', 'urgent', 'in_progress', '2026-03-14 03:15:00+00', NULL, 'Mira', 'anxious', NULL, 'SSO provisioning mismatch for new contractors.'),
  (5004, 102, 'billing', 'medium', 'resolved', '2026-01-21 05:45:00+00', '2026-01-22 06:10:00+00', 'Noah', 'positive', 4.8, 'Requested detailed tax breakdown for enterprise invoice.'),
  (5005, 103, 'onboarding', 'low', 'resolved', '2026-02-03 11:20:00+00', '2026-02-05 10:00:00+00', 'Isha', 'positive', 4.9, 'Needed guidance for team-level permission templates.'),
  (5006, 103, 'technical', 'high', 'open', '2026-03-09 12:40:00+00', NULL, 'Rohan', 'frustrated', NULL, 'Dashboard export job timing out for large reports.'),
  (5007, 104, 'billing', 'high', 'waiting_customer', '2026-03-06 00:30:00+00', NULL, 'Mira', 'neutral', NULL, 'Refund request pending confirmation for duplicate seats.'),
  (5008, 104, 'feature_request', 'low', 'open', '2026-03-11 02:05:00+00', NULL, 'Isha', 'positive', NULL, 'Asked for daily ops digest to be shared over Slack.'),
  (5009, 105, 'technical', 'medium', 'resolved', '2026-02-18 06:50:00+00', '2026-02-19 08:15:00+00', 'Noah', 'positive', 4.1, 'Timezone issue in weekly finance exports.'),
  (5010, 105, 'billing', 'low', 'resolved', '2026-01-08 07:30:00+00', '2026-01-09 09:00:00+00', 'Noah', 'neutral', 3.9, 'Clarified starter-plan overage calculation.'),
  (5011, 106, 'technical', 'urgent', 'open', '2026-03-15 04:10:00+00', NULL, 'Rohan', 'anxious', NULL, 'Production workflow approvals are intermittently failing.'),
  (5012, 106, 'billing', 'medium', 'resolved', '2026-02-27 04:40:00+00', '2026-02-28 05:25:00+00', 'Mira', 'positive', 4.7, 'Updated billing entity after procurement change.')
ON CONFLICT (ticket_id) DO NOTHING;

