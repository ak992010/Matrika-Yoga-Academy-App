# Track 3: AlloyDB Natural-Language Query App

This project satisfies the Track 3 requirement from the public APAC GenAI Academy brief:
- uses AlloyDB for PostgreSQL
- uses a custom dataset instead of the default lab dataset
- uses AlloyDB AI natural language to convert natural language into SQL
- executes the generated SQL and returns meaningful results

Use case sentence:
- exploring customer support tickets for a SaaS help desk

Custom dataset
- `helpdesk.organizations`
- `helpdesk.support_tickets`

Files
- `sql/01_schema.sql`: creates the custom dataset and comments
- `sql/02_seed.sql`: loads sample support-ticket records
- `sql/03_nl_setup.sql`: installs `alloydb_ai_nl`, creates the configuration, registers the schema, and generates schema context

API
- `GET /healthz`
- `GET /sample-questions`
- `POST /query`

Example request

```bash
curl -X POST http://127.0.0.1:8080/query \
  -H "Content-Type: application/json" \
  -d '{
    "question": "Which premium customers have open billing tickets in Singapore?"
  }'
```

Environment preparation
1. Enable the AlloyDB flag `alloydb_ai_nl.enabled` on the instance.
2. Enable Vertex AI integration for the AlloyDB cluster.
3. Connect to the target database.
4. Run the SQL files in this order:

```bash
psql "$DATABASE_URL" -f sql/01_schema.sql
psql "$DATABASE_URL" -f sql/02_seed.sql
psql "$DATABASE_URL" -f sql/03_nl_setup.sql
```

Local run

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export DATABASE_URL='postgresql+psycopg://username:password@host:5432/database_name'
export TRACK3_NL_CONFIG_ID='support_helpdesk_nl_config'
uvicorn api:app --host 0.0.0.0 --port 8080
```

If you want to run the SQL setup through `psql`, use a standard PostgreSQL connection string or libpq connection options there, for example:

```bash
export PGURI='postgresql://username:password@host:5432/database_name'
psql "$PGURI" -f sql/01_schema.sql
psql "$PGURI" -f sql/02_seed.sql
psql "$PGURI" -f sql/03_nl_setup.sql
```

Cloud Run deployment example

```bash
gcloud builds submit --tag gcr.io/$GOOGLE_CLOUD_PROJECT/track3-alloydb-nl-query
gcloud run deploy track3-alloydb-nl-query \
  --image gcr.io/$GOOGLE_CLOUD_PROJECT/track3-alloydb-nl-query \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --set-env-vars TRACK3_NL_CONFIG_ID=support_helpdesk_nl_config,DATABASE_URL='postgresql+psycopg://username:password@host:5432/database_name'
```

Sample questions
- Which premium customers have open billing tickets in Singapore?
- Show unresolved high-priority tickets assigned to Mira.
- Which organizations in Japan reported the lowest average CSAT?
- Count open technical tickets created after 2026-03-01.

Suggested submission artifacts
- repository URL
- a screenshot or short demo video showing generated SQL and returned rows
- optional deployed URL if you expose the API publicly
