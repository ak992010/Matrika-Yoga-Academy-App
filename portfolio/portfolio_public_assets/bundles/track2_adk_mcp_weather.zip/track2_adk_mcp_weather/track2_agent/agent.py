from __future__ import annotations

import os
import sys
from pathlib import Path

from mcp import StdioServerParameters
from google.adk.agents import LlmAgent
from google.adk.tools import McpToolset
from google.adk.tools.mcp_tool.mcp_session_manager import StdioConnectionParams


BASE_DIR = Path(__file__).resolve().parents[1]
MCP_SERVER_PATH = BASE_DIR / "mcp_server.py"
MODEL_NAME = (
    os.getenv("TRACK2_MODEL")
    or os.getenv("GOOGLE_GENAI_MODEL")
    or "gemini-2.5-flash"
)

mcp_toolset = McpToolset(
    connection_params=StdioConnectionParams(
        server_params=StdioServerParameters(
            command=sys.executable,
            args=[str(MCP_SERVER_PATH)],
            env=dict(os.environ),
            cwd=str(BASE_DIR),
        )
    )
)

root_agent = LlmAgent(
    name="track2_mcp_weather_agent",
    model=MODEL_NAME,
    description="Answers city weather questions using live MCP-connected tool data.",
    instruction=(
        "You are a travel weather assistant. "
        "Always use the MCP tool to retrieve live city weather data before answering. "
        "Ground every factual weather statement in the tool response. "
        "If the tool returns no data, explain that clearly instead of guessing."
    ),
    tools=[mcp_toolset],
)
