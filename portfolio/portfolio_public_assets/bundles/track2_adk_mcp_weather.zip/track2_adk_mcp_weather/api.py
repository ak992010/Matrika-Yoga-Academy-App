from __future__ import annotations

import os

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from google.genai import types
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService

from track2_agent.agent import root_agent

APP_NAME = "track2-adk-mcp-weather"

app = FastAPI(
    title="Track 2 ADK MCP Weather Agent",
    version="1.0.0",
    description="A Gemini + ADK agent that retrieves live weather data through MCP.",
)

session_service = InMemorySessionService()
runner = Runner(
    app_name=APP_NAME,
    agent=root_agent,
    session_service=session_service,
)


class WeatherBriefRequest(BaseModel):
    city: str = Field(..., min_length=2, max_length=80)
    question: str = Field(..., min_length=10, max_length=500)


class WeatherBriefResponse(BaseModel):
    answer: str
    session_id: str
    model: str


def _extract_text_from_event(event) -> str:
    if not getattr(event, "content", None) or not event.content.parts:
        return ""
    pieces: list[str] = []
    for part in event.content.parts:
        text = getattr(part, "text", None)
        if text:
            pieces.append(text)
    return "".join(pieces).strip()


async def _run_agent(prompt: str) -> WeatherBriefResponse:
    user_id = "track2-api-user"
    session = await session_service.create_session(app_name=APP_NAME, user_id=user_id)
    final_text = ""

    async for event in runner.run_async(
        user_id=user_id,
        session_id=session.id,
        new_message=types.UserContent(parts=[types.Part.from_text(text=prompt)]),
    ):
        if event.is_final_response():
            final_text = _extract_text_from_event(event) or final_text

    if not final_text:
        raise HTTPException(status_code=502, detail="The agent returned an empty response.")

    return WeatherBriefResponse(
        answer=final_text,
        session_id=session.id,
        model=os.getenv("TRACK2_MODEL") or os.getenv("GOOGLE_GENAI_MODEL") or "gemini-2.5-flash",
    )


@app.get("/healthz")
async def healthz() -> dict[str, str]:
    return {
        "status": "ok",
        "service": APP_NAME,
        "model": os.getenv("TRACK2_MODEL") or os.getenv("GOOGLE_GENAI_MODEL") or "gemini-2.5-flash",
    }


@app.post("/weather-brief", response_model=WeatherBriefResponse)
async def weather_brief(payload: WeatherBriefRequest) -> WeatherBriefResponse:
    prompt = (
        "Use the MCP tool to retrieve live weather data for the city below. "
        "Then answer the user question clearly and briefly. "
        "Include the current temperature, wind speed, precipitation, and a practical recommendation. "
        "Do not guess if the tool does not return data.\n\n"
        f"CITY: {payload.city}\n"
        f"QUESTION: {payload.question}"
    )
    return await _run_agent(prompt)

