# Gen AI Academy APAC Edition 2026 Submission Playbook

This file summarizes the live Hack2Skill requirements captured on 2026-03-22 from the authenticated APAC GenAI Academy portal.

## Current Scope

The active project work in this workspace covers the three public project tracks:

1. Track 1: Build and Deploy AI Agents
2. Track 2: Connect AI Agents to Real-World Data
3. Track 3: Build and Migrate faster with AI-Ready Databases

## Live Portal Requirements

### Required form

Title:
- Share your Google Skills Public Profile link

Fields:
- Enter your email
- Share your Google Skills Public profile link

Status in portal:
- no response submitted yet

What cannot be fabricated:
- your real Google Skills public profile URL

### Google Skills Lab submission

Title:
- Google Skills Lab Submission

Deadline:
- March 31, 2026 12:01 AM IST

Required upload:
- one image screenshot showing the selected Google Skills lab progress

Guide requirement:
- the screenshot must show your profile dropdown menu open
- the relevant lab name and progress must be clearly visible

Status in portal:
- no response submitted yet

What cannot be fabricated:
- your real Google Skills lab completion screenshot

### Track 1 project submission

Title:
- Project Submission (Track 1) - Build and Deploy AI Agents

Deadline:
- March 31, 2026 11:59 PM IST

Required fields:
- Cloud Run Deployment Link
- Final Project PPT as PDF

Portal note:
- all submission links must be publicly accessible
- presentation should be concise and cover project overview and outcomes

Status in portal:
- no response submitted yet

### Track 2 project submission

Title:
- Project Submission (Track 2) - Connect AI Agents to Real-World Data

Deadline:
- March 31, 2026 11:59 PM IST

Required fields:
- Cloud Run Deployment Link
- Final Project PPT as PDF

Portal note:
- all submission links must be publicly accessible
- the PDF field is marked optional in the portal, but a deck is already prepared locally

Status in portal:
- no response submitted yet

### Track 3 project submission

Title:
- Project Submission (Track 3) - Build and Migrate faster with AI-Ready Databases

Deadline:
- March 31, 2026 11:59 PM IST

Required fields:
- Cloud Run Deployment Link
- Final Project PPT as PDF

Portal note:
- all submission links must be publicly accessible

Status in portal:
- no response submitted yet

## Local Artifacts Already Prepared

### Source projects

- `track1_adk_cloud_run`
- `track2_adk_mcp_weather`
- `track3_alloydb_nl_query`

### Distribution zips

- `dist/track1_adk_cloud_run.zip`
- `dist/track2_adk_mcp_weather.zip`
- `dist/track3_alloydb_nl_query.zip`

### Submission PDFs

- `submission_artifacts/pdf/track1_final_project_ppt.pdf`
- `submission_artifacts/pdf/track2_final_project_ppt.pdf`
- `submission_artifacts/pdf/track3_final_project_ppt.pdf`

### PDF generator

- `scripts/build_submission_pdfs.py`

### PDF preview renders

- `tmp/pdf_previews/track1_final_project_ppt.pdf.png`
- `tmp/pdf_previews/track2_final_project_ppt.pdf.png`
- `tmp/pdf_previews/track3_final_project_ppt.pdf.png`

## Remaining External Dependencies

These items still depend on your real accounts or cloud configuration:

- a valid Google Skills public profile URL
- a real Google Skills lab screenshot for the selected track
- Cloud Run deployment URLs for Track 1, Track 2, and Track 3
- Gemini credentials or Vertex AI access for Track 1 and Track 2
- an actual AlloyDB instance and connection string for Track 3 if you want a live public deployment

## Current GCP Constraint

The active GCP project configured locally is:
- `matrika-academy-app-b5a04d`

Known blockers in that project:
- `run.googleapis.com` is disabled
- `aiplatform.googleapis.com` is disabled

This means public deployment links cannot be produced until the relevant APIs are enabled and deployment credentials are available.

## Recommended Next Order

1. Provide or confirm the target GCP project for deployment.
2. Enable Cloud Run, Cloud Build, Artifact Registry, and Vertex AI if you want real public links from this workspace.
3. Deploy Track 1 and Track 2 using Gemini credentials or Vertex AI.
4. Deploy Track 3 only if you also have a reachable AlloyDB database and a valid `DATABASE_URL`.
5. Submit your real Google Skills public profile link.
6. Upload your real Google Skills lab screenshot.
7. Upload the prepared project PDFs and the resulting public Cloud Run links into the portal.

## Optional Google Skills Labs Listed In The Portal

- Track 1: Connect to Remote Agents with ADK and the Agent2Agent (A2A) SDK
- Track 2: Model Context Protocol (MCP) Tools with ADK Agents
- Track 3: Configure Vector Search in AlloyDB

These are useful for your learning path and screenshot evidence, but the local code in this workspace is independent of the Google Skills platform itself.
