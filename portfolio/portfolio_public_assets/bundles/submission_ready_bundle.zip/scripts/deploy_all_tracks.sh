#!/usr/bin/env bash

set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
GCLOUD_BIN="${GCLOUD_BIN:-gcloud}"
PROJECT_ID="${GOOGLE_CLOUD_PROJECT:-}"
REGION="${GOOGLE_CLOUD_LOCATION:-us-central1}"

if [[ -z "${PROJECT_ID}" ]]; then
  echo "Set GOOGLE_CLOUD_PROJECT before running this script."
  exit 1
fi

if ! command -v "${GCLOUD_BIN}" >/dev/null 2>&1; then
  echo "gcloud not found. Set GCLOUD_BIN to a valid gcloud executable."
  exit 1
fi

TRACK1_SERVICE="${TRACK1_SERVICE:-track1-adk-summarizer}"
TRACK2_SERVICE="${TRACK2_SERVICE:-track2-mcp-weather}"
TRACK3_SERVICE="${TRACK3_SERVICE:-track3-alloydb-nl-query}"

TRACK1_IMAGE="gcr.io/${PROJECT_ID}/${TRACK1_SERVICE}"
TRACK2_IMAGE="gcr.io/${PROJECT_ID}/${TRACK2_SERVICE}"
TRACK3_IMAGE="gcr.io/${PROJECT_ID}/${TRACK3_SERVICE}"

TRACK1_ENVS="${TRACK1_ENVS:-GOOGLE_GENAI_USE_VERTEXAI=true,GOOGLE_CLOUD_PROJECT=${PROJECT_ID},GOOGLE_CLOUD_LOCATION=${REGION},TRACK1_MODEL=gemini-2.5-flash}"
TRACK2_ENVS="${TRACK2_ENVS:-GOOGLE_GENAI_USE_VERTEXAI=true,GOOGLE_CLOUD_PROJECT=${PROJECT_ID},GOOGLE_CLOUD_LOCATION=${REGION},TRACK2_MODEL=gemini-2.5-flash}"
TRACK3_ENVS_DEFAULT="TRACK3_NL_CONFIG_ID=support_helpdesk_nl_config"
TRACK3_ENVS="${TRACK3_ENVS:-${TRACK3_ENVS_DEFAULT}}"

deploy_track() {
  local folder="$1"
  local image="$2"
  local service="$3"
  local envs="$4"

  echo
  echo "Building ${service} from ${folder}"
  "${GCLOUD_BIN}" builds submit "${ROOT_DIR}/${folder}" --tag "${image}"

  echo "Deploying ${service}"
  "${GCLOUD_BIN}" run deploy "${service}" \
    --image "${image}" \
    --platform managed \
    --region "${REGION}" \
    --allow-unauthenticated \
    --set-env-vars "${envs}"
}

deploy_track "track1_adk_cloud_run" "${TRACK1_IMAGE}" "${TRACK1_SERVICE}" "${TRACK1_ENVS}"
deploy_track "track2_adk_mcp_weather" "${TRACK2_IMAGE}" "${TRACK2_SERVICE}" "${TRACK2_ENVS}"

if [[ -n "${DATABASE_URL:-}" ]]; then
  deploy_track "track3_alloydb_nl_query" "${TRACK3_IMAGE}" "${TRACK3_SERVICE}" "${TRACK3_ENVS},DATABASE_URL=${DATABASE_URL}"
else
  echo
  echo "Skipping Track 3 deployment because DATABASE_URL is not set."
  echo "Set DATABASE_URL and rerun if you want a live public Track 3 endpoint."
fi

echo
echo "Deployment script finished."
