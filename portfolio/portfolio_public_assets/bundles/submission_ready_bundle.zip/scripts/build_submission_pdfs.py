from __future__ import annotations

from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import (
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)


ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = ROOT / "submission_artifacts" / "pdf"


TRACKS = [
    {
        "slug": "track1_final_project_ppt.pdf",
        "title": "Track 1 - Build and Deploy AI Agents",
        "subtitle": "ADK + Gemini executive summarizer prepared for Cloud Run",
        "tag": "APAC GenAI Academy",
        "theme": colors.HexColor("#1E5631"),
        "problem": [
            "Teams often lose time turning raw meeting notes into short action-ready summaries.",
            "The solution exposes one focused AI capability through a simple HTTP API.",
        ],
        "solution": [
            "Built with Google ADK and Gemini via an LlmAgent.",
            "Accepts free-form notes and returns concise bullet or paragraph summaries.",
            "Packaged as a FastAPI service with Cloud Run deployment instructions.",
        ],
        "architecture": [
            "api.py exposes GET /healthz and POST /summarize.",
            "track1_adk_agent/agent.py initializes the ADK summarizer agent.",
            "Dockerfile and requirements.txt make the service Cloud Run ready.",
        ],
        "flow": [
            "Client sends text, style, and max_words.",
            "FastAPI validates the request and calls the ADK agent.",
            "Gemini produces a concise summary and the API returns JSON.",
        ],
        "evidence": [
            "Python syntax checks passed.",
            "Project structure, Dockerfile, and env configuration are prepared for deployment.",
            "Live inference is pending Gemini credentials or Vertex AI enablement.",
        ],
        "artifacts": [
            "Expected portal artifact: Cloud Run deployment link.",
            "Expected portal artifact: Final Project PPT in PDF format.",
            "Suggested demo capture: successful POST /summarize response.",
        ],
        "repo_points": [
            "Folder: track1_adk_cloud_run",
            "Entry point: api.py",
            "Agent module: track1_adk_agent/agent.py",
        ],
    },
    {
        "slug": "track2_final_project_ppt.pdf",
        "title": "Track 2 - Connect AI Agents to Real-World Data",
        "subtitle": "ADK travel-weather assistant using MCP and live Open-Meteo data",
        "tag": "APAC GenAI Academy",
        "theme": colors.HexColor("#0B4F6C"),
        "problem": [
            "A useful agent should ground answers in live external data instead of only model memory.",
            "This track demonstrates an MCP-connected agent that answers city weather questions.",
        ],
        "solution": [
            "Built an ADK agent that connects to a local MCP server through McpToolset.",
            "The MCP server fetches live weather data from Open-Meteo.",
            "The API returns practical weather guidance through a single HTTP endpoint.",
        ],
        "architecture": [
            "api.py exposes GET /healthz and POST /weather-brief.",
            "track2_agent/agent.py wires the ADK agent to the MCP toolset.",
            "mcp_server.py serves weather tools over stdio with FastMCP.",
        ],
        "flow": [
            "User asks a weather question for a city.",
            "Agent calls the MCP weather tool.",
            "Tool resolves the city, fetches live forecast data, and returns grounded context.",
            "Gemini produces the final natural-language brief.",
        ],
        "evidence": [
            "Python syntax checks passed.",
            "MCP weather function was exercised locally and returned live Open-Meteo data.",
            "Live ADK + Gemini response is pending Gemini credentials or Vertex AI enablement.",
        ],
        "artifacts": [
            "Expected portal artifact: Cloud Run deployment link.",
            "Expected portal artifact: Final Project PPT in PDF format.",
            "Optional artifact: screenshot showing live-weather grounded response.",
        ],
        "repo_points": [
            "Folder: track2_adk_mcp_weather",
            "Entry point: api.py",
            "MCP server: mcp_server.py",
        ],
    },
    {
        "slug": "track3_final_project_ppt.pdf",
        "title": "Track 3 - AI-Ready Databases with AlloyDB",
        "subtitle": "Natural-language querying over a custom SaaS helpdesk dataset",
        "tag": "APAC GenAI Academy",
        "theme": colors.HexColor("#7A3E00"),
        "problem": [
            "Support teams need quick answers from relational data without writing SQL by hand.",
            "This project uses AlloyDB AI natural language over a custom dataset, not the default lab data.",
        ],
        "solution": [
            "Designed a helpdesk dataset with organizations and support tickets.",
            "Added schema, seed data, and AlloyDB AI NL configuration SQL.",
            "Built a FastAPI app that converts natural language into SQL, validates it, and executes read-only queries.",
        ],
        "architecture": [
            "api.py exposes GET /healthz, GET /sample-questions, and POST /query.",
            "db.py manages SQLAlchemy connections and query execution.",
            "guards.py enforces read-only SQL safety checks before execution.",
            "sql/01_schema.sql, sql/02_seed.sql, and sql/03_nl_setup.sql prepare AlloyDB AI NL.",
        ],
        "flow": [
            "User sends a natural-language analytics question.",
            "App requests SQL from alloydb_ai_nl.get_sql(config_id, question).",
            "Generated SQL is validated for read-only safety.",
            "Validated SQL is executed and rows are returned to the client.",
        ],
        "evidence": [
            "Python syntax checks passed.",
            "Health and sample-question helpers ran locally.",
            "SQL guard accepts SELECT queries and rejects destructive statements.",
        ],
        "artifacts": [
            "Expected portal artifact: deployment link if exposed publicly.",
            "Expected portal artifact: Final Project PPT in PDF format.",
            "Suggested demo capture: generated SQL plus returned rows.",
        ],
        "repo_points": [
            "Folder: track3_alloydb_nl_query",
            "API entry point: api.py",
            "Database setup: sql/01_schema.sql, sql/02_seed.sql, sql/03_nl_setup.sql",
        ],
    },
]


def styles():
    base = getSampleStyleSheet()
    return {
        "title": ParagraphStyle(
            "Title",
            parent=base["Heading1"],
            fontName="Helvetica-Bold",
            fontSize=22,
            leading=28,
            textColor=colors.white,
            spaceAfter=8,
        ),
        "subtitle": ParagraphStyle(
            "Subtitle",
            parent=base["BodyText"],
            fontName="Helvetica",
            fontSize=11,
            leading=15,
            textColor=colors.white,
        ),
        "h2": ParagraphStyle(
            "H2",
            parent=base["Heading2"],
            fontName="Helvetica-Bold",
            fontSize=15,
            leading=19,
            textColor=colors.HexColor("#1F2937"),
            spaceAfter=8,
        ),
        "body": ParagraphStyle(
            "Body",
            parent=base["BodyText"],
            fontName="Helvetica",
            fontSize=10.2,
            leading=14,
            alignment=TA_LEFT,
            textColor=colors.HexColor("#111827"),
            spaceAfter=6,
        ),
        "bullet": ParagraphStyle(
            "Bullet",
            parent=base["BodyText"],
            fontName="Helvetica",
            fontSize=10,
            leading=13.5,
            leftIndent=12,
            bulletIndent=0,
            textColor=colors.HexColor("#111827"),
            spaceAfter=4,
        ),
        "small": ParagraphStyle(
            "Small",
            parent=base["BodyText"],
            fontName="Helvetica",
            fontSize=9,
            leading=12,
            textColor=colors.HexColor("#4B5563"),
        ),
    }


def header_block(track: dict, sty: dict) -> Table:
    content = [
        [Paragraph(track["tag"], sty["small"])],
        [Paragraph(track["title"], sty["title"])],
        [Paragraph(track["subtitle"], sty["subtitle"])],
    ]
    table = Table(content, colWidths=[7.0 * inch])
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), track["theme"]),
                ("TOPPADDING", (0, 0), (-1, -1), 12),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 14),
                ("LEFTPADDING", (0, 0), (-1, -1), 16),
                ("RIGHTPADDING", (0, 0), (-1, -1), 16),
            ]
        )
    )
    return table


def info_table(left_title: str, left_items: list[str], right_title: str, right_items: list[str], sty: dict) -> Table:
    left_flow = [Paragraph(f"<b>{left_title}</b>", sty["h2"])]
    left_flow.extend(Paragraph(item, sty["bullet"], bulletText="-") for item in left_items)
    right_flow = [Paragraph(f"<b>{right_title}</b>", sty["h2"])]
    right_flow.extend(Paragraph(item, sty["bullet"], bulletText="-") for item in right_items)
    table = Table([[left_flow, right_flow]], colWidths=[3.35 * inch, 3.35 * inch])
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (0, 0), colors.HexColor("#F8FAFC")),
                ("BACKGROUND", (1, 0), (1, 0), colors.HexColor("#F8FAFC")),
                ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#CBD5E1")),
                ("INNERGRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#E2E8F0")),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("TOPPADDING", (0, 0), (-1, -1), 10),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
                ("LEFTPADDING", (0, 0), (-1, -1), 12),
                ("RIGHTPADDING", (0, 0), (-1, -1), 12),
            ]
        )
    )
    return table


def build_story(track: dict) -> list:
    sty = styles()
    story = [header_block(track, sty), Spacer(1, 0.24 * inch)]
    story.append(Paragraph("Problem And Solution", sty["h2"]))
    story.append(
        info_table(
            "Problem",
            track["problem"],
            "Implemented Solution",
            track["solution"],
            sty,
        )
    )
    story.append(Spacer(1, 0.22 * inch))
    story.append(Paragraph("System Design", sty["h2"]))
    story.append(
        info_table(
            "Architecture",
            track["architecture"],
            "Request Flow",
            track["flow"],
            sty,
        )
    )
    story.append(PageBreak())
    story.append(header_block(track, sty))
    story.append(Spacer(1, 0.24 * inch))
    story.append(Paragraph("Validation Summary", sty["h2"]))
    for item in track["evidence"]:
        story.append(Paragraph(item, sty["bullet"], bulletText="-"))
    story.append(Spacer(1, 0.12 * inch))
    story.append(Paragraph("Submission Notes", sty["h2"]))
    for item in track["artifacts"]:
        story.append(Paragraph(item, sty["bullet"], bulletText="-"))
    story.append(Spacer(1, 0.12 * inch))
    story.append(Paragraph("Repository Highlights", sty["h2"]))
    for item in track["repo_points"]:
        story.append(Paragraph(item, sty["bullet"], bulletText="-"))
    story.append(Spacer(1, 0.18 * inch))
    story.append(
        Table(
            [
                [
                    Paragraph(
                        "Current status: code and packaging are complete. Public deployment links depend on the target GCP project configuration and credentials available at submission time.",
                        sty["body"],
                    )
                ]
            ],
            colWidths=[7.0 * inch],
            style=TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#FFF7ED")),
                    ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#FDBA74")),
                    ("TOPPADDING", (0, 0), (-1, -1), 10),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
                    ("LEFTPADDING", (0, 0), (-1, -1), 12),
                    ("RIGHTPADDING", (0, 0), (-1, -1), 12),
                ]
            ),
        )
    )
    return story


def draw_footer(canvas, doc):
    page = canvas.getPageNumber()
    canvas.saveState()
    canvas.setFont("Helvetica", 9)
    canvas.setFillColor(colors.HexColor("#6B7280"))
    canvas.drawString(doc.leftMargin, 0.45 * inch, "Prepared for Hack2Skill APAC GenAI Academy submission")
    canvas.drawRightString(A4[0] - doc.rightMargin, 0.45 * inch, f"Page {page}")
    canvas.restoreState()


def build_pdf(track: dict) -> Path:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    output = OUT_DIR / track["slug"]
    doc = SimpleDocTemplate(
        str(output),
        pagesize=A4,
        leftMargin=0.55 * inch,
        rightMargin=0.55 * inch,
        topMargin=0.6 * inch,
        bottomMargin=0.75 * inch,
        title=track["title"],
    )
    doc.build(build_story(track), onFirstPage=draw_footer, onLaterPages=draw_footer)
    return output


def main():
    for track in TRACKS:
        output = build_pdf(track)
        print(output)


if __name__ == "__main__":
    main()
