from __future__ import annotations

import os
import uuid

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from google.genai import types
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService

from track1_adk_agent.agent import root_agent

APP_NAME = "track1-adk-summarizer"

app = FastAPI(
    title="Track 1 ADK Summarizer",
    version="1.0.0",
    description="A single-task Gemini + ADK summarization API prepared for Cloud Run.",
)

session_service = InMemorySessionService()
runner = Runner(
    app_name=APP_NAME,
    agent=root_agent,
    session_service=session_service,
)


class SummarizeRequest(BaseModel):
    text: str = Field(..., min_length=20, description="The raw text to summarize.")
    style: str = Field(
        default="bullets",
        pattern="^(bullets|paragraph)$",
        description="Output style for the summary.",
    )
    max_words: int = Field(
        default=80,
        ge=20,
        le=300,
        description="Upper bound for the summary length.",
    )


class SummarizeResponse(BaseModel):
    summary: str
    session_id: str
    model: str


def _extract_text_from_event(event) -> str:
    if not getattr(event, "content", None) or not event.content.parts:
        return ""
    chunks: list[str] = []
    for part in event.content.parts:
        text = getattr(part, "text", None)
        if text:
            chunks.append(text)
    return "".join(chunks).strip()


async def _run_summary(prompt: str) -> SummarizeResponse:
    user_id = "track1-api-user"
    session = await session_service.create_session(app_name=APP_NAME, user_id=user_id)
    final_text = ""

    async for event in runner.run_async(
        user_id=user_id,
        session_id=session.id,
        new_message=types.UserContent(parts=[types.Part.from_text(text=prompt)]),
    ):
        if event.is_final_response():
            final_text = _extract_text_from_event(event) or final_text

    if not final_text:
        raise HTTPException(status_code=502, detail="The agent returned an empty response.")

    return SummarizeResponse(
        summary=final_text,
        session_id=session.id,
        model=os.getenv("TRACK1_MODEL") or os.getenv("GOOGLE_GENAI_MODEL") or "gemini-2.5-flash",
    )


@app.get("/healthz")
async def healthz() -> dict[str, str]:
    return {
        "status": "ok",
        "service": APP_NAME,
        "model": os.getenv("TRACK1_MODEL") or os.getenv("GOOGLE_GENAI_MODEL") or "gemini-2.5-flash",
    }


@app.post("/summarize", response_model=SummarizeResponse)
async def summarize(payload: SummarizeRequest) -> SummarizeResponse:
    request_id = uuid.uuid4().hex[:8]
    prompt = (
        "You are handling summarization request "
        f"{request_id}. Summarize the following content in {payload.style} style, "
        f"keep the response under {payload.max_words} words, and include only the summary.\n\n"
        f"CONTENT:\n{payload.text}"
    )
    return await _run_summary(prompt)

