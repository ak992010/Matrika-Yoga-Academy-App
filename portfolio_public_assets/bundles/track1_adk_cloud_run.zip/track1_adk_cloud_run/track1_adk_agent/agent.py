from __future__ import annotations

import os

from google.adk.agents import LlmAgent


MODEL_NAME = (
    os.getenv("TRACK1_MODEL")
    or os.getenv("GOOGLE_GENAI_MODEL")
    or "gemini-2.5-flash"
)

root_agent = LlmAgent(
    name="track1_summarizer_agent",
    model=MODEL_NAME,
    description="Summarizes long-form text into concise executive-ready takeaways.",
    instruction=(
        "You are a production summarization agent. "
        "Your only job is to summarize user-provided text. "
        "Do not invent facts, do not answer unrelated questions, and do not add a preamble. "
        "Return a clean summary in the style requested by the user prompt."
    ),
)
